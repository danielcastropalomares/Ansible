<?php

define("HOST_UP", 0);
define("HOST_DOWN", 1);
define("HOST_UNREACHABLE", 2);
define("SERVICE_OK", 0);
define("SERVICE_WARNING", 1);
define("SERVICE_CRITICAL", 2);
define("SERVICE_UNKNOWN", 3);

define('VIEW_FRONTLINE', 0);
define('VIEW_ALL', 1);
define('VIEW_DISPLAY', 2);