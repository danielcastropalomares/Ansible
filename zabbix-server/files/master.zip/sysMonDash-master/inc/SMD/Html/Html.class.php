<?php
/**
 * sysMonDash
 *
 * @author    nuxsmin
 * @link      http://cygnux.org
 * @copyright 2012-2016 Rubén Domínguez nuxsmin@cygnux.org
 *
 * This file is part of sysMonDash.
 *
 * sysMonDash is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * sysMonDash is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with sysMonDash.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

namespace SMD\Html;

use SMD\Core\ConfigBackendCheckMK;
use SMD\Core\ConfigBackendLivestatus;
use SMD\Core\ConfigBackendSMD;
use SMD\Core\ConfigBackendStatus;
use SMD\Core\ConfigBackendZabbix;

class Html
{
    /**
     * Limpia los datos recibidos de un formulario.
     *
     * @param string $data con los datos a limpiar
     * @return false|string con los datos limpiados
     */
    public static function sanitize(&$data)
    {
        if (empty($data)) {
            return $data;
        }

        if (is_array($data)) {
            array_walk_recursive($data, '\SMD\Html\Html::sanitize');
        } else {
            $data = strip_tags($data);

            // Fix &entity\n;
            $data = str_replace(array('&amp;', '&lt;', '&gt;'), array('&amp;amp;', '&amp;lt;', '&amp;gt;'), $data);
            $data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
            $data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
            $data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');

            // Remove any attribute starting with "on" or xmlns
            $data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);

            // Remove javascript: and vbscript: protocols
            $data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
            $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
            $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);

            // Only works in IE: <span style="width: expression(alert('Ping!'));"></span>
            $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
            $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
            $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);

            // Remove namespaced elements (we do not need them)
            $data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);

            do {
                // Remove really unwanted tags
                $old_data = $data;
                $data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
            } while ($old_data !== $data);
        }
        return $data;
    }

    /**
     * Procesar los backends desde el formulario de configuración y guardarlos
     *
     * @param array $backends
     * @return array
     * @throws \Exception
     */
    public static function processFormBackends($backends)
    {
        $BackendsConfig = array();
        $ConfigBackend = null;

        foreach ($backends as $backend => $n) {
            foreach ($n as $config) {
                switch ($backend) {
                    case 'status':
                        $ConfigBackend = new ConfigBackendStatus($config['path']);
                        break;
                    case 'livestatus':
                        $ConfigBackend = new ConfigBackendLivestatus($config['path']);
                        break;
                    case 'checkmk':
                        $ConfigBackend = new ConfigBackendCheckMK($config['path']);
                        break;
                    case 'zabbix':
                        $ConfigBackend = new ConfigBackendZabbix($config['version'], $config['url'], $config['user'], $config['pass'], $config['level']);
                        break;
                    case 'smd':
                        $ConfigBackend = new ConfigBackendSMD($config['url'], $config['token']);
                        break;
                }

                $active = (isset($config['active']) && $config['active'] === 'on');
                $ConfigBackend->setActive($active);
                $ConfigBackend->setAlias($config['alias']);

                $BackendsConfig[] = $ConfigBackend;
            }
        }

        return $BackendsConfig;
    }
    
    /**
     * Truncar un texto a una determinada longitud.
     *
     * @param string $text  la cadena a truncar
     * @param int    $limit la longitud máxima de la cadena
     * @param string $ellipsis
     * @return string con el texto truncado
     *
     * @link http://www.pjgalbraith.com/truncating-text-html-with-php/
     */
    public static function truncate($text, $limit, $ellipsis = '...')
    {
        if (strlen($text) > $limit) {
            $text = trim(mb_substr($text, 0, $limit)) . $ellipsis;
        }

        return $text;
    }
}